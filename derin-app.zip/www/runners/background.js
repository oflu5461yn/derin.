// DERİN arka plan kontrolü: Android ~15 dakikada bir çalıştırır.
// AFAD'dan son 45 dakikanın M4+ depremlerini alır, yeni olanlar için bildirim gönderir.
addEventListener('checkQuakes', async (resolve, reject) => {
  try {
    const pad = n => String(n).padStart(2, '0');
    const f = d => d.getUTCFullYear() + '-' + pad(d.getUTCMonth() + 1) + '-' + pad(d.getUTCDate()) + 'T' +
      pad(d.getUTCHours()) + ':' + pad(d.getUTCMinutes()) + ':' + pad(d.getUTCSeconds());
    const now = new Date();
    const s = new Date(now.getTime() - 45 * 60000), e = new Date(now.getTime() + 60 * 60000);
    const url = 'https://servisnet.afad.gov.tr/apigateway/deprem/apiv2/event/filter?start=' + f(s) + '&end=' + f(e) +
      '&minlat=34&maxlat=43&minlon=25&maxlon=45.5&minmag=4&orderby=timedesc&limit=50';
    const res = await fetch(url);
    const list = JSON.parse(await res.text());
    let seen = [];
    try { const v = await CapacitorKV.get('seen'); if (v && v.value) seen = JSON.parse(v.value); } catch (_) {}
    const out = [];
    for (const x of (Array.isArray(list) ? list : [])) {
      const id = String(x.eventID);
      if (seen.indexOf(id) >= 0) continue;
      seen.push(id);
      const m = Number(x.magnitude);
      if (!(m >= 4)) continue;
      const age = Math.max(0, Math.round((now.getTime() - Date.parse(String(x.date).replace(/Z?$/, 'Z'))) / 60000));
      out.push({
        id: (parseInt(id, 10) || now.getTime()) % 2147483647,
        title: 'Büyük deprem · M ' + m.toFixed(1),
        body: x.location + ' · ' + (age < 1 ? 'az önce' : age + ' dk önce') + ' · derinlik ' + Math.round(Number(x.depth)) + ' km',
        scheduleAt: new Date(now.getTime() + 1000),
        autoCancel: true
      });
    }
    if (out.length) await CapacitorNotifications.schedule(out);
    await CapacitorKV.set('seen', JSON.stringify(seen.slice(-200)));
    resolve();
  } catch (err) {
    reject(err);
  }
});
