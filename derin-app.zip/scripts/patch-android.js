// Background Runner için android/app/build.gradle'a gerekli kütüphane yolunu ekler (tekrar çalıştırılabilir).
const fs = require('fs');
const p = 'android/app/build.gradle';
if (!fs.existsSync(p)) process.exit(0);
let g = fs.readFileSync(p, 'utf8');
const line = "dirs '../../node_modules/@capacitor/background-runner/android/src/main/libs', 'libs'";
if (!g.includes('background-runner/android/src/main/libs')) {
  const anchor = "dirs '../capacitor-cordova-android-plugins/src/main/libs', 'libs'";
  if (g.includes(anchor)) g = g.replace(anchor, anchor + '\n        ' + line);
  else g += '\nrepositories {\n    flatDir {\n        ' + line + '\n    }\n}\n';
  fs.writeFileSync(p, g);
  console.log('[derin] build.gradle güncellendi (background-runner)');
}
const m = 'android/app/src/main/AndroidManifest.xml';
if (fs.existsSync(m)) {
  let x = fs.readFileSync(m, 'utf8');
  if (!x.includes('SCHEDULE_EXACT_ALARM')) {
    x = x.replace('</manifest>', '    <uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM" />\n    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />\n</manifest>');
    fs.writeFileSync(m, x);
  }
}
