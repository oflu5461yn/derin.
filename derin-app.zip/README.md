# DERİN

Türkiye için canlı deprem ve hava haritası (Android).

- Depremler: AFAD, Kandilli Rasathanesi (© Boğaziçi Ü. KRDAE, ticari olmayan kullanım), EMSC, USGS
- Hava: Open-Meteo
- Sınırlar: OCHA/HDX COD-AB-TUR (CC BY-IGO)
- Harita altlığı: © OpenStreetMap katkıcıları, © CARTO

## APK

Her `main` gönderiminde GitHub Actions APK derler ve **Releases** bölümüne `app-debug.apk` olarak koyar.
Telefonda Releases sayfasından indirip kurun (bilinmeyen kaynaklardan yüklemeye izin vermeniz gerekir).
